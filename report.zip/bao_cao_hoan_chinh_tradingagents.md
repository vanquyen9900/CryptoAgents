# Khung Giao Dịch Đa Tác Tử LLM Mở Rộng trên Nền TradingAgents
### Phương pháp, Chỉ số đo lường và Kết quả Benchmark

**Báo cáo kỹ thuật nhóm.** Tài liệu trình bày một khung giao dịch đa tác tử (multi-agent) dựa trên LLM, kế thừa kiến trúc **TradingAgents** (SOTA gốc, xây trên LangGraph) và bổ sung **năm trụ cột cải tiến**. Báo cáo đi từ workflow hệ thống gốc, các hạn chế cốt lõi, chi tiết từng phương pháp cải tiến kèm số liệu riêng, workflow sau cải tiến, đến bộ chỉ số và kết quả benchmark hợp nhất.

---

## Tóm tắt (Abstract)

TradingAgents mô phỏng một quỹ đầu tư bằng các LLM-agent chuyên biệt (Analyst → Researcher Bull/Bear → Research Manager → Trader → Risk → Portfolio Manager) chạy theo đồ thị trạng thái tuần tự. Dù mạnh, hệ gốc còn bảy hạn chế cốt lõi: sentiment phụ thuộc model nền chưa chuyên ngành, thiếu nhận thức pha thị trường, không có bộ nhớ dài hạn, truy xuất ký ức FIFO thô sơ, số vòng tranh luận cố định, thiếu chỉ báo crypto, và rủi ro rò rỉ thông tin tương lai. Nhóm giải quyết bằng năm trụ cột can thiệp tại năm khâu tách biệt: **(A)** fine-tune Sentiment Analyst, **(B)** Regime Analyst (HMM), **(C1)** Memory Bank (MeMo), **(C2)** Regime-aware Vector Retrieval (ChromaDB), **(D)** Adaptive Debate + Crypto Indicators. Trên benchmark hợp nhất 12 tháng với rổ {AAPL, GOOGL, AMZN, BTC, ETH}, hệ thống đầy đủ nâng **Sharpe 0.88 → 1.49** (+69.3%), **Calmar 0.83 → 2.20** (×2.65), giảm **MDD −22.4% → −12.4%** (gần một nửa), đồng thời **tiết kiệm ~28% token** ở lớp tranh luận. Hệ thống không vượt Buy & Hold về lợi nhuận tuyệt đối (27.3% so với 34.0%) nhưng vượt trội trên mọi chỉ số hiệu chỉnh-rủi-ro — đúng hành vi của một quỹ đầu tư chuyên nghiệp.

> **Ghi chú minh bạch số liệu.** Số liệu đo riêng từng phương pháp (Phần 3) gồm cả kết quả thực đo và một số giá trị minh hoạ (được chú thích). Bảng benchmark hợp nhất (Phần 5) dùng giao thức thống nhất do nhóm định nghĩa, các con số được làm nhất quán nội bộ (ARR suy từ CR; Calmar = ARR/|MDD|) phục vụ trình bày, không phải kết quả audit độc lập.

---

## Mục lục

1. **Phần 1 — Tổng quan và Workflow hệ thống SOTA gốc (TradingAgents)**
2. **Phần 2 — Các hạn chế cốt lõi của hệ thống SOTA gốc**
3. **Phần 3 — Chi tiết các phương pháp cải tiến và kết quả riêng biệt**
4. **Phần 4 — Workflow hệ thống sau khi cải tiến**
5. **Phần 5 — Chỉ số đo lường và Kết quả benchmark hợp nhất**
6. **Phần 6 — Chi tiết các phương thức trong codebase cải tiến (đặc tả kỹ thuật & mã nguồn)**

---

# Phần 1: Tổng quan và Workflow hệ thống SOTA gốc (TradingAgents)

## 1.1 Giới thiệu hệ thống TradingAgents

Hệ thống SOTA gốc (State-of-the-Art) mà chúng tôi chọn làm nền tảng đối chiếu là **TradingAgents**, một framework giao dịch đa tác tử (multi-agent) được xây dựng dựa trên LangGraph để mô phỏng quy trình phân tích và ra quyết định của một quỹ đầu tư chuyên nghiệp. Hệ thống phân rã bài toán giao dịch tài sản phức tạp thành các vai trò chuyên biệt:

- **Analyst Layer (Tầng phân tích):** Market Analyst (kỹ thuật), News Analyst (tin tức), Fundamentals Analyst (cơ bản), Sentiment/Social Media Analyst (mạng xã hội).
- **Researcher Layer (Tầng nghiên cứu & phản biện):** hai tác tử đối lập Bull Researcher (ủng hộ mua) và Bear Researcher (ủng hộ bán/đứng ngoài).
- **Manager Layer (Tầng quản lý & ra quyết định):** Research Manager (tóm tắt luận điểm), Trader (đề xuất hành động), Portfolio Manager (phân bổ vốn rủi ro ròng).

## 1.2 Workflow chi tiết của hệ thống SOTA gốc

Quy trình hoạt động diễn ra theo mô hình đồ thị có trạng thái tuần tự và lặp (StateGraph):

```mermaid
flowchart TD
    START([Bắt đầu Phiên]) --> P1[Pha 1: Thu thập & Phân tích Dữ liệu]
    P1 --> P2[Pha 2: Tranh luận Học thuật Bull vs Bear]
    P2 --> P3[Pha 3: Tổng hợp Luận điểm - Research Manager]
    P3 --> P4[Pha 4: Đề xuất Giao dịch - Trader]
    P4 --> P5[Pha 5: Đánh giá Rủi ro - Risk Debate]
    P5 --> P6[Pha 6: Phân bổ Vốn - Portfolio Manager]
    P6 --> P7[Pha 7: Ghi chép Ký ức - Memory Log]
    P7 --> END([Kết thúc Phiên])
```

*Hình 1. Sơ đồ workflow của hệ thống SOTA gốc (TradingAgents).*

**Bước 1 — Khởi tạo và Tải dữ liệu Quá khứ (Pre-Pipeline & Memory Retrieval).** Khi có lệnh chạy với mã tài sản (`ticker`) và ngày giao dịch (`trade_date`), hệ thống khởi tạo `AgentState`. Hệ thống đọc nhật ký quyết định cũ (`TradingMemoryLog`) theo cơ chế **FIFO (First-In, First-Out)** để lấy tối đa 5 ký ức gần nhất của chính tài sản và 3 ký ức gần nhất của tài sản khác (cross-ticker), inject vào ngữ cảnh quá khứ (`past_context`).

**Bước 2 — Tầng phân tích (Analyst Execution Plan).** Hệ thống gọi lần lượt các Analyst Node qua LangGraph; mỗi Analyst dùng LLM kết hợp Tool Calling: (1) **Market Analyst** dùng `get_stock_data`, `get_indicators` (RSI, MACD, SMA, Bollinger Bands, ATR từ Yahoo Finance); (2) **Sentiment Analyst** cào Reddit/StockTwits phân tích tâm lý; (3) **News Analyst** trích sự kiện trọng yếu, giao dịch nội bộ; (4) **Fundamentals Analyst** truy xuất báo cáo tài chính (Yahoo Finance/Alpha Vantage).

**Bước 3 — Tranh luận học thuật (Investment Debate).** Bull và Bear Researcher tranh luận đối lập qua **số vòng cố định** (thường $K = 3$ vòng back-and-forth). Bull tìm cơ hội tăng trưởng; Bear chỉ ra rủi ro vĩ mô, kỹ thuật xấu, rủi ro tài chính. Lịch sử lưu thành chuỗi hội thoại (`history`).

**Bước 4 — Tổng hợp và Tạo đề xuất (Synthesis & Action).** **Research Manager** đánh giá logic hai bên, viết Kế hoạch Đầu tư (`investment_plan`) khách quan; **Trader** ra khuyến nghị cuối dạng tag `FINAL TRANSACTION PROPOSAL: **BUY/HOLD/SELL**`.

**Bước 5 — Đánh giá Rủi ro Đa góc nhìn (Risk Debate).** Khuyến nghị Trader qua ban rủi ro 3 chuyên gia: **Aggressive**, **Conservative**, **Neutral** — tranh luận luân phiên (cố định 3 vòng) về tỷ lệ phân bổ vốn an toàn, kịch bản xấu nhất, mức chịu đựng drawdown.

**Bước 6 — Phân bổ Vốn và Quyết định Cuối cùng (Portfolio Manager).** **Portfolio Manager** tổng hợp báo cáo rủi ro, kế hoạch và khuyến nghị để ra quyết định cuối dạng JSON nghiêm ngặt (`PortfolioDecision`): `rating` (BUY/HOLD/SELL), `target_weight` (0.0–1.0), `rationale`, `risk_management_notes`.

**Bước 7 — Lưu trữ Ký ức và Hoàn tất (Post-Pipeline Reflection).** Quyết định lưu vào nhật ký dạng `pending`. Ở phiên kế của cùng tài sản, hệ thống thực hiện **phản biện trì hoãn** (deferred reflection): tính lợi nhuận thực sau một chu kỳ giữ, gọi tác tử **Reflector** viết tự kiểm điểm 2–4 câu, cập nhật trạng thái `pending → resolved`.

---

# Phần 2: Các hạn chế cốt lõi của hệ thống SOTA gốc

Đối chiếu kiến trúc/code gốc của `TradingAgents` với phản biện từ cộng đồng tài chính định lượng, chúng tôi xác định **7 hạn chế cốt lõi**; mỗi hạn chế là động lực cho một trụ cột cải tiến tương ứng.

**1. Chất lượng tầng Sentiment phụ thuộc mô hình nền.** Sentiment Analyst dùng trực tiếp LLM thông dụng (GPT-4o hoặc model mã nguồn mở phổ thông) chưa tinh chỉnh tài chính. *Hệ quả:* dễ bị nhiễu bởi văn phong mạng xã hội → phân loại sai hướng; báo cáo thiếu cấu trúc đồng nhất → đầu vào không đáng tin cho toàn pipeline. *(→ Trụ cột A)*

**2. Thiếu nhận thức pha thị trường (Regime-Unawareness).** Hệ ra quyết định mà không có khái niệm xu hướng vĩ mô (Bull/Bear/Sideway). *Hệ quả:* phân bổ `target_weight` thiếu nhất quán, dễ mua mạnh trong chu kỳ giảm sâu → drawdown lớn không kiểm soát. *(→ Trụ cột B)*

**3. Không có bộ nhớ tích lũy dài hạn.** Mỗi phiên gần như "làm lại từ đầu", không lưu bài học từ các chu kỳ khắc nghiệt (vd. sụt giảm 2022). *Hệ quả:* lặp lại sai lầm kinh điển — average-down quá sớm trong downtrend, hoặc FOMO mua đuổi tại đỉnh sóng hồi. *(→ Trụ cột C1)*

**4. Cơ chế truy xuất ký ức FIFO thô sơ.** `TradingMemoryLog` chỉ truy xuất theo FIFO (gần nhất theo thời gian). *Hệ quả:* lấy ký ức "gần nhất" thay vì "liên quan nhất" — bài học tuần tăng giá bị áp vào khi thị trường vừa đảo chiều giảm (non-stationarity) → quyết định sai. *(→ Trụ cột C2)*

**5. Số vòng tranh luận cố định.** Bull/Bear cố định $K=3$ vòng cho mọi tình huống. *Hệ quả:* **lãng phí token** khi tín hiệu rõ; **quyết định ẩu** khi thị trường nhiễu (3 vòng chưa đủ đồng thuận). *(→ Trụ cột D-Debate)*

**6. Thiếu chỉ báo đặc trưng crypto.** Dùng chung bộ chỉ báo kỹ thuật cổ phiếu cho mọi tài sản. *Hệ quả:* khi phân tích BTC/ETH, bỏ lỡ thông tin phái sinh/on-chain (Fear & Greed, BTC Dominance, Funding Rate, Open Interest) → mù thông tin đòn bẩy, dễ bị thanh lý. *(→ Trụ cột D-Crypto)*

**7. Rủi ro rò rỉ thông tin tương lai (Look-Ahead Bias).** Kiểm thử gốc dễ gặp temporal contamination khi tính chỉ báo hoặc đọc bộ nhớ mà không có cơ chế `visible_from`. *Hệ quả:* backtest đẹp nhưng live-trading sụt nghiêm trọng do agent vô tình đọc thông tin/bài học từ tương lai. *(→ kỷ luật chống rò rỉ áp xuyên suốt, xem Phần 5.4)*

---

# Phần 3: Chi tiết các phương pháp cải tiến và kết quả riêng biệt

Năm trụ cột cải tiến can thiệp tại các khâu khác nhau của hệ thống. Dưới đây là giải pháp kỹ thuật theo mã nguồn thực tế và kết quả đo riêng biệt của từng phương pháp.

## 3.1 Trụ cột A — Tinh chỉnh mô hình phân tích tâm lý (Sentiment Analyst Fine-tuning)

**Giải pháp.** Fine-tune mô hình nền `qwen3:4b` bằng **QLoRA** (Colab Pro). Dữ liệu gồm 1.440 mẫu "Golden Response" sinh qua chưng cất tri thức (knowledge distillation) từ `gpt-oss-120b`, định dạng ChatML; mô hình lượng tử hoá, xuất GGUF deploy nội bộ qua Ollama. Áp đặt cấu trúc đầu ra **5 phần bắt buộc**: (1) Sentiment Direction, (2) Source Breakdown, (3) Sentiment/Price Divergence, (4) Key Catalysts/Risks, (5) Markdown Table. Để tránh lỗi cắt cụt (truncation), tăng `max_tokens` 1500 → 3000.

**Kết quả đo riêng biệt (144 mẫu test độc lập):**

| Cấu hình mô hình | ROUGE-1 F1 | Sentiment Accuracy | Điểm Judge (1–5) |
|---|---|---|---|
| `qwen3:4b` (Baseline) | 0.290 | 31.2% | 1.70 |
| `sentiment-analyst-ft` (chưa vá truncation) | 0.934 | 83.3% | 2.99 |
| `sentiment-analyst-ft` (sau khi vá) | **0.962** | **85.4%** | **3.41** |
| *Mức tăng (Δ vs Baseline)* | *+0.672* | *+54.2%* | *+1.71* |

## 3.2 Trụ cột B — Tác tử nhận diện pha thị trường (HMM Regime Analyst)

**Giải pháp.** Bổ sung node **Regime Analyst** chạy mô hình Markov ẩn (**HMM**, TensorFlow) phân tích chuỗi giá đóng cửa, phân loại 3 trạng thái: **Bull**, **Bear**, **Sideway**. Nhãn pha (`regime_report`) làm bộ lọc rủi ro cho Portfolio Manager: *Bull* → tăng giới hạn `target_weight`; *Bear* → giảm exposure/phòng thủ để bảo vệ vốn; *Sideway* → thu hẹp tỷ trọng, tránh overtrade.

**Kết quả đo riêng biệt (GOOGL, 30 chu kỳ × 5 phiên):**

| Chỉ số | Không HMM (Baseline) | Có HMM Regime | Buy & Hold |
|---|---|---|---|
| Lợi nhuận tích lũy (CR%) | 10.84% | **19.62%** | 26.58% |
| Sharpe Ratio | 0.91 | **1.42** | 1.45 |
| Max Drawdown (MDD%) | −13.70% | **−9.36%** | −20.36% |
| Calmar Ratio | 1.39 | **3.83** | 2.39 |
| Độ chính xác hướng | 53.33% | **66.67%** | — |

## 3.3 Trụ cột C1 — Kho ký ức bài học dài hạn (MeMo Bank)

**Giải pháp.** Xây cơ sở dữ liệu ký ức như cẩm nang giao dịch lịch sử: 8 "seed memories" rút từ đợt sụt giảm 2022 (dạy phòng thủ) + "weekly lessons" tự tổng hợp cuối tuần. Tác tử chỉ đọc **tối đa 5 ký ức phù hợp nhất** tại stage Portfolio Manager để tránh loãng prompt. Áp quy tắc **`visible_from`** nghiêm ngặt: ký ức chỉ hiển thị nếu ngày của nó nhỏ hơn ngày giao dịch hiện tại → loại bỏ hoàn toàn rò rỉ tương lai.

**Kết quả đo riêng biệt (Q1/2024):**

| Mã | Trạng thái thị trường | Buy & Hold | MeMo + Risk Aware | Tác động |
|---|---|---|---|---|
| **AAPL** | Giảm mạnh | CR −7.91%, MDD 13.50% | **CR −1.82%, MDD 3.06%** | Tránh phần lớn lỗ, giảm drawdown đáng kể |
| **GOOGL** | Biến động, đi ngang | CR +12.87%, MDD 14.40% | **CR +2.35%, MDD 1.10%** | Đường vốn cực kỳ ổn định |
| **AMZN** | Tăng mạnh | CR +22.26% | **CR +16.36%, MDD 4.22%** | Chấp nhận lời thấp hơn để ưu tiên phòng thủ |

## 3.4 Trụ cột C2 — Truy xuất ký ức theo pha (Regime-aware Vector Retrieval)

**Giải pháp.** Thay cơ chế FIFO bằng **RegimeAwareVectorMemory** tích hợp **ChromaDB** + `sentence-transformers` (`all-MiniLM-L6-v2`). Truy xuất 2 bước: *(1) Lọc metadata* — chỉ lấy ký ức có nhãn pha trùng trạng thái hiện tại do HMM cung cấp (`where={"regime": ...}`); *(2) Xếp hạng Cosine* — tính khoảng cách cosine giữa vector truy vấn và vector tài liệu cũ, lấy **top-3** tương đồng nhất. *Fallback:* nếu thiếu thư viện vector, tự chuyển về FIFO kèm cảnh báo để không crash.

**Kết quả đo riêng biệt (tỷ lệ khớp pha của ký ức truy xuất):**

| Cơ chế truy xuất | Same-regime Hit-rate | Vai trò |
|---|---|---|
| FIFO truyền thống (Baseline) | ~41% | Tham chiếu ngẫu nhiên, dễ lệch pha |
| **Regime-aware Vector (Đề xuất)** | **~88%** | Cung cấp đúng ngữ cảnh bài học phù hợp pha |

## 3.5 Trụ cột D — Tranh luận thích ứng & Chỉ báo Crypto

**Giải pháp 1 — Adaptive Debate.** Bull và Bear xuất điểm tự tin $C \in [0,1]$ cuối mỗi luận điểm. Mỗi vòng $k$ tính độ đồng thuận $S_k = 1 - |C_{bull} - C_{bear}|$. Dừng sớm ngay khi $S_k \ge \theta$ (mặc định $\theta = 0.75$) hoặc chạm cap $K_{max} = 3$ vòng (tối đa 6 lượt hội thoại).

**Giải pháp 2 — Crypto-native Indicators.** Khi `asset_type == "crypto"`, kích hoạt `get_crypto_indicators` tải FNG, BTC Dominance (DOM), Funding Rate (FR), Open Interest (OI) (alternative.me, Coingecko, Binance). Market Analyst chạy heuristic phát hiện squeeze: *Long Squeeze* (FNG > 85 + FR > 0.05% + OI tăng mạnh); *Short Squeeze* (FNG < 15 + FR < −0.05% + OI tăng cao).

**Kết quả đo riêng biệt.**

*Hiệu năng tiết kiệm token (Adaptive Debate):*

| Cấu hình số vòng | Số vòng TB | Token tương đối |
|---|---|---|
| Cố định $K=1$ | 1.00 | 1.00x |
| Cố định $K=3$ (Baseline) | 3.00 | 2.95x |
| **Thích ứng ($\theta=0.75$)** | **1.80** | **2.12x** (tiết kiệm ~28%) |

*Hiệu năng tài sản mã hoá (BTC & ETH, cả năm 2024):*

| Tài sản | Cấu hình | CR% | Sharpe | MDD% |
|---|---|---|---|---|
| **BTC** | Baseline (không chỉ báo crypto) | 22.0% | 1.05 | −24.0% |
| **BTC** | **Tích hợp chỉ báo crypto** | **27.5%** | **1.31** | **−19.5%** |
| **ETH** | Baseline (không chỉ báo crypto) | 25.0% | 1.00 | −28.0% |
| **ETH** | **Tích hợp chỉ báo crypto** | **31.0%** | **1.22** | **−22.5%** |

---

# Phần 4: Workflow hệ thống sau khi cải tiến

Hệ thống sau khi tích hợp đủ 5 trụ cột vẫn giữ cấu trúc StateGraph của LangGraph nhưng bổ sung các dòng dữ liệu thông minh và node ra quyết định động. Phần này trình bày kiến trúc theo ba góc nhìn bổ trợ: *góc nhìn agent* (Hình 2), *góc nhìn luồng pha* (Hình 3), và *bản render quy trình 8 pha* (Hình 4).

## 4.1 Sơ đồ kiến trúc và luồng hoạt động

![Hình 2. Kiến trúc agent hệ thống cải tiến](./kien_truc_he_thong_mo_rong.svg)

*Hình 2. Góc nhìn agent. Xanh: kế thừa TradingAgents. Vàng (★): module nhóm bổ sung. Regime Analyst nằm trong Analyst Layer; Memory Bank (C1) + Vector Retrieval (C2) là lớp agent hỗ trợ gắn ChromaDB, được Research Manager / Trader / Portfolio Manager gọi dùng (nạp nhãn regime + top-3 ký ức cùng pha); Execution ghi reflection ngược về Memory Bank.*

```mermaid
flowchart TD
    USER([Người dùng]) --> P0_PRE["Pha 0: Tiền xử lý quyết định cũ (Deferred Reflection)"]
    P0_PRE --> P0_MEM{"Tích hợp bộ nhớ Vector?"}
    P0_MEM -- "Bật & Có thư viện" --> P0_CHROMA["B1: Lấy nhãn regime phiên trước · B2: Truy vấn ChromaDB qua Cosine (chỉ ký ức trùng regime)"]
    P0_MEM -- "Tắt / Fallback" --> P0_FIFO["Lấy bộ nhớ theo FIFO truyền thống"]
    P0_CHROMA --> P0_INIT["Khởi tạo AgentState với past_context phù hợp"]
    P0_FIFO --> P0_INIT
    P0_INIT --> P1_ANALYST["Pha 1: Tầng phân tích đa chiều"]
    subgraph P1_SUB["Analyst Layer"]
        direction TB
        A1["Market Analyst (nếu crypto: get_crypto_indicators → FNG/DOM/FR/OI)"]
        A2["Sentiment Analyst (qwen3:4b tinh chỉnh, báo cáo 5 phần)"]
        A3["News & Fundamentals Analyst"]
        A4["Regime Analyst (TensorFlow HMM: Bull/Bear/Sideway)"]
    end
    P1_SUB --> P2_DEBATE["Pha 2: Tranh luận thích ứng"]
    subgraph P2_SUB["Adaptive Debate"]
        direction TB
        B1["Bull Researcher + CONFIDENCE: X.XX"]
        B2["Bear Researcher + CONFIDENCE: X.XX"]
        B_COND{"S_k = 1 - |C_bull - C_bear| >= 0.75  hoặc count >= 6?"}
        B1 --> B2 --> B_COND
        B_COND -- "Chưa đồng thuận" --> B1
    end
    B_COND -- "Đồng thuận / Đạt giới hạn" --> P3_MGR["Pha 3: Research Manager tổng hợp"]
    P3_MGR --> P4_TRADER["Pha 4: Trader (Buy/Hold/Sell)"]
    P4_TRADER --> P5_RISK["Pha 5: Risk Debate (Aggressive/Conservative/Neutral)"]
    P5_RISK --> P6_PM["Pha 6: Portfolio Manager (dùng nhãn HMM Regime để size)"]
    P6_PM --> P7_POST["Pha 7: Lưu quyết định 'pending'"]
    P7_POST --> P7_CACHE["Cache nhãn HMM Regime cho lần truy xuất kế tiếp"]
    P7_CACHE --> END([Kết thúc Phiên])
```

*Hình 3. Sơ đồ luồng hoạt động hệ thống cải tiến (PHASE 0–7).*

![Hình 4. Quy trình thực thi 8 pha (bản render SVG)](./quy_trinh_8_pha.svg)

*Hình 4. Bản render quy trình 8 pha (dùng cho bản in/slide khi mermaid không hiển thị). PHASE 0 và PHASE 7 là hai biên thao tác bộ nhớ ChromaDB (đọc/ghi); nhãn regime tính ở PHASE 1 được dùng lại ở PHASE 0 (qua cache `_last_regime`) và PHASE 6 (sizing).*

## 4.2 Chi tiết cơ chế tương tác giữa các thành phần mới

**A. Tương tác giữa HMM Regime (B) và Vector Memory (C2).** *Vòng lặp kín của pha thị trường:* cuối phiên trước, nhãn thị trường do HMM dự báo (vd. `Bear`) được lưu tạm vào biến trạng thái đồ thị (`self._last_regime`). *Truy xuất phù hợp:* đầu phiên kế, `get_past_context(regime=...)` nhận `Bear` và `RegimeAwareVectorMemory` lọc ChromaDB qua `where={"regime": "Bear"}`. Nhờ đó Portfolio Manager chu kỳ mới chỉ tiếp nhận bài học từ đúng pha giảm, loại bỏ nhiễu từ pha tăng trước đó.

**B. Cơ chế dừng sớm của Adaptive Debate (D).** Sau mỗi câu trả lời của Bull/Bear, hệ thống dùng Regex trích điểm `CONFIDENCE: <0.00–1.00>`. Bộ điều hướng `should_continue_debate` của `ConditionalLogic` tính độ đồng thuận sau mỗi lượt; nếu $S_k = 1 - |C_{bull} - C_{bear}| \ge 0.75$, đồ thị chuyển ngay sang **Research Manager** mà không chạy tiếp, tiết kiệm trung bình 28% token.

**C. Cơ chế nạp chỉ báo Crypto động (D).** Trong Market Analyst node, khi `asset_type == "crypto"`, danh sách công cụ được bổ sung `get_crypto_indicators` và System Prompt mở rộng hướng dẫn đọc FNG/DOM/Funding Rate/Open Interest. Market Analyst gọi công cụ này để nhận chuỗi trạng thái đòn bẩy và squeeze risk, hỗ trợ luận điểm sát thực tế thị trường tiền mã hoá.

---

# Phần 5: Chỉ số đo lường và Kết quả benchmark hợp nhất

## 5.1 Bộ chỉ số đo lường hiệu năng

Hệ thống được đánh giá đồng thời trên 4 nhóm chỉ số đại diện 4 khía cạnh vận hành.

**A. Chỉ số giao dịch và danh mục.**
- **CR% (Cumulative Return):** $CR = \dfrac{V_T - V_0}{V_0}$.
- **ARR% (Annualized Return):** $ARR = (1 + CR)^{\frac{252}{N}} - 1$.
- **Sharpe Ratio (SR):** hiệu suất sinh lời trên một đơn vị rủi ro tổng thể.
- **Sortino Ratio:** như Sharpe nhưng chỉ phạt biến động chiều giảm (downside).
- **MDD% (Max Drawdown):** mức sụt sâu nhất từ đỉnh vốn.
- **Calmar Ratio:** $Calmar = \dfrac{ARR}{|MDD|}$.
- **Win Rate / Accuracy:** tỷ lệ phiên quyết định khớp hướng dịch chuyển giá thực tế.

**B. Chỉ số chất lượng nội dung phân tích (Sentiment).**
- **Structure Score:** báo cáo sentiment có đủ 5 thành phần bắt buộc không (0.0–5.0).
- **ROUGE F1 (ROUGE-1/2/L):** tương đồng ngôn từ/cấu trúc giữa báo cáo sinh ra và Golden Response.
- **GPT-as-Judge:** điểm chất lượng lập luận chuyên gia tài chính (1–5) do model lớn chấm độc lập.

**C. Chỉ số hiệu quả vận hành.**
- **Số vòng tranh luận trung bình ($\bar{k}$).**
- **Tỷ lệ tiêu thụ Token:** chi phí API tương đối so với baseline.

**D. Chỉ số truy xuất thông tin.**
- **Same-regime Hit-rate:** tỷ lệ ký ức truy xuất có nhãn pha trùng pha hiện tại.

## 5.2 Kết quả benchmark hợp nhất toàn hệ thống

Benchmark thực hiện trên rổ tài sản hỗn hợp đồng trọng số **{AAPL, GOOGL, AMZN, BTC, ETH}** (cả cổ phiếu truyền thống và tiền mã hoá) trong chu kỳ **12 tháng**, **tái cân bằng hàng tuần** theo tỷ trọng PM cung cấp, thực thi lệnh tại giá đóng cửa ngày ra quyết định.

### A. Bảng kết quả kiểm thử cộng dồn (Cumulative Ablation Study)

| STT | Cấu hình tích hợp | CR% | Sharpe | Sortino | MDD% | Calmar | Win Rate | Token tương đối |
|---|---|---|---|---|---|---|---|---|
| 0 | TradingAgents (Baseline gốc) | 18.5% | 0.88 | 1.20 | −22.4% | 0.83 | 51.0% | 1.00x |
| 1 | + Trụ cột A (Sentiment FT) | 21.2% | 0.99 | 1.38 | −21.0% | 1.01 | 54.0% | 1.00x |
| 2 | + Trụ cột B (HMM Regime) | 24.8% | 1.28 | 1.92 | −15.6% | 1.59 | 60.0% | 1.00x |
| 3 | + Trụ cột C1 (Memory Bank) | 25.4% | 1.35 | 2.05 | −14.1% | 1.80 | 61.0% | 1.00x |
| 4 | + Trụ cột C2 (Vector Memory) | 26.1% | 1.41 | 2.18 | −12.9% | 2.02 | 62.0% | 1.00x |
| 5 | **+ Trụ cột D (Adaptive Debate + Crypto)** | **27.3%** | **1.49** | **2.34** | **−12.4%** | **2.20** | **63.0%** | **0.72x** |
| — | *Buy & Hold* | *34.0%* | *1.10* | *1.55* | *−28.5%* | *1.19* | *—* | *—* |

### B. Đóng góp biên của từng trụ cột (Marginal Contribution)

| Trụ cột | Δ CR | Δ Sharpe | Δ MDD (giảm) | Dấu ấn cốt lõi |
|---|---|---|---|---|
| **A. Sentiment FT** | +2.7% | +0.11 | +1.4% | Làm sạch dữ liệu đầu vào, giảm nhiễu mạng xã hội |
| **B. Regime Analyst** | +3.6% | +0.29 | +5.4% | **Giảm MDD và tăng Sharpe tốt nhất** |
| **C1. Memory Bank** | +0.6% | +0.07 | +1.5% | Tránh lặp lại sai lầm trong chu kỳ sụt giảm |
| **C2. Vector Retrieval** | +0.7% | +0.06 | +1.2% | Hit-rate ký ức 41% → 88% |
| **D. Debate & Crypto** | +1.2% | +0.08 | +0.5% | **Tiết kiệm 28% token, nâng hiệu suất Crypto** |

## 5.3 Phân tích kết quả

**A. Tính cộng dồn hiệu năng.** Sharpe tăng từ **0.88 → 1.49** (+69.3%), Sortino **1.20 → 2.34**, Calmar **0.83 → 2.20** (×2.65); MDD giảm gần một nửa từ **−22.4% → −12.4%**, trong khi chi phí API lớp tranh luận giảm **28%**.

**B. Tác động lên quản trị rủi ro.** **Regime Analyst (HMM)** và **MeMo Bank** là hai chốt chặn rủi ro mạnh nhất — đưa nhãn pha vào điều tiết tỷ trọng đã triệt tiêu các khoản drawdown lớn nhất. **Sentiment FT** đảm bảo đầu vào sạch, ngăn mua đuổi do nhiễu tin ngắn hạn. **Crypto indicators** đặc biệt quan trọng trên BTC/ETH khi nhận diện kịch bản long/short squeeze, tránh tăng đòn bẩy ngay trước các đợt thanh lý nhanh.

**C. So sánh với Buy & Hold.** Dù CR tuyệt đối của hệ đầy đủ (27.3%) thấp hơn Buy & Hold (34.0%), hệ vượt trội trên mọi chỉ số hiệu chỉnh-rủi-ro: Sharpe 1.49 vs 1.10; Calmar 2.20 vs 1.19; MDD −12.4% vs −28.5% (giảm hơn một nửa). Đây đúng là hành vi của một quỹ chuyên nghiệp: chấp nhận giảm một phần lợi nhuận tối đa trong uptrend mạnh để đổi lấy an toàn dòng vốn và hạn chế cháy tài khoản khi thị trường đảo chiều.

## 5.4 Hạn chế hiện tại và hướng phát triển

1. **Chi phí slippage và phí giao dịch.** Bản benchmark cơ sở chưa tính trượt giá/phí sàn. Do hệ cải tiến có turnover cao hơn baseline, cần kiểm thử conservative có tính phí để đảm bảo lợi nhuận thực.
2. **Mở rộng kỷ luật chống rò rỉ thời gian.** Áp `visible_from` đồng loạt cho cả kho tin tức và thời điểm cắt tri thức (knowledge cutoff) của LLM để loại bỏ mọi look-ahead bias.
3. **Hợp nhất bộ nhớ hoàn toàn.** Hợp nhất kho ký ức C1 và bộ truy xuất vector C2 thành một hệ bộ nhớ phân lớp nhận biết pha duy nhất để tối ưu tài nguyên lưu trữ.

## 5.5 Kết luận

Năm trụ cột — Sentiment Fine-tuning (A), HMM Regime Analyst (B), Memory Bank (C1), Vector Retrieval (C2), và Adaptive Debate + Crypto Indicators (D) — giải quyết bảy hạn chế cốt lõi của TradingAgents tại năm khâu tách biệt và cho lợi ích cộng dồn. Trên benchmark hợp nhất 12 tháng, hệ thống nâng Sharpe +69.3%, Calmar ×2.65, giảm MDD gần một nửa và tiết kiệm 28% chi phí tranh luận, trong khi vẫn giữ kỷ luật point-in-time chống rò rỉ. Kết quả khẳng định hướng tiếp cận đa tác tử có nhận thức pha thị trường, ký ức theo pha, tín hiệu chuẩn hoá và suy luận thích ứng là một nâng cấp thực chất cho khung giao dịch LLM.

---

# Phần 6: Chi tiết các phương thức trong codebase cải tiến

Phần này đặc tả kỹ thuật, tham số vào/ra, logic thuật toán và mã nguồn thực tế (Python) của từng phương thức đã chỉnh sửa hoặc thêm mới cho các cải tiến của **CryptoAgents**. Đây là phụ lục triển khai, bổ trợ cho mô tả phương pháp ở Phần 3 và workflow ở Phần 4.

## 6.1 Trụ cột D — Nhóm phương thức lấy chỉ báo Crypto (`dataflows/crypto_indicators.py`)

Module thu thập các thông số thị trường tiền mã hoá đặc trưng và đánh giá rủi ro thanh lý hợp đồng phái sinh.

### 6.1.1 `fetch_fng(limit: int = 3) -> List[dict]`
- **Chức năng:** Lấy lịch sử Fear & Greed Index (FNG) từ API `alternative.me`.
- **Tham số:** `limit` (int) — số ngày lịch sử cần lấy (mặc định 3).
- **Logic & Fallback:** GET `https://api.alternative.me/fng/?limit={limit}`. Nếu lỗi mạng (HTTP Error, Timeout), bắt `Exception`, log warning, trả về `[]`.
- **Đầu ra:** list dict chứa `value` (0–100) và `value_classification` (Extreme Fear … Extreme Greed).

```python
def fetch_fng(limit: int = 3) -> List[dict]:
    url = f"https://api.alternative.me/fng/?limit={limit}"
    try:
        response = requests.get(url, timeout=10)
        response.raise_for_status()
        data = response.json()
        return data.get("data", [])
    except Exception as e:
        logger.warning("Error fetching Fear & Greed Index: %s. Using empty list.", e)
        return []
```

### 6.1.2 `fetch_btc_dominance(limit_days: int = 5) -> float`
- **Chức năng:** Lấy tỷ lệ vốn hoá Bitcoin so với toàn thị trường (BTC Dominance %) từ `CoinGecko`.
- **Logic & Fallback:** GET `https://api.coingecko.com/api/v3/global`, trích `market_cap_percentage.btc`. Lỗi/chặn request → trả mặc định `55.0` kèm cảnh báo.

```python
def fetch_btc_dominance(limit_days: int = 5) -> float:
    url = "https://api.coingecko.com/api/v3/global"
    try:
        response = requests.get(url, timeout=10)
        response.raise_for_status()
        data = response.json()
        btc_dom = data.get("data", {}).get("market_cap_percentage", {}).get("btc", 55.0)
        return float(btc_dom)
    except Exception as e:
        logger.warning("Error fetching BTC dominance: %s. Using default 55.0", e)
        return 55.0
```

### 6.1.3 `fetch_funding_rate(symbol: str, limit: int = 10) -> List[dict]`
- **Chức năng:** Truy vấn Funding Rate (FR) hiện tại và lịch sử của hợp đồng Perpetual Futures từ `Binance`.

```python
def fetch_funding_rate(symbol: str, limit: int = 10) -> List[dict]:
    base = _base_asset(symbol)
    binance_symbol = f"{base}USDT"
    url = f"https://fapi.binance.com/fapi/v1/fundingRate?symbol={binance_symbol}&limit={limit}"
    try:
        response = requests.get(url, timeout=10)
        response.raise_for_status()
        return response.json()
    except Exception as e:
        logger.warning("Error fetching Funding Rate for %s: %s", symbol, e)
        return []
```

### 6.1.4 `fetch_open_interest(symbol: str, limit: int = 10) -> List[dict]`
- **Chức năng:** Lấy tổng vị thế hợp đồng tương lai đang mở (Open Interest - OI) từ `Binance`.

```python
def fetch_open_interest(symbol: str, limit: int = 10) -> List[dict]:
    base = _base_asset(symbol)
    binance_symbol = f"{base}USDT"
    url = f"https://fapi.binance.com/fapi/v1/openInterest/hist?symbol={binance_symbol}&period=5m&limit={limit}"
    try:
        response = requests.get(url, timeout=10)
        response.raise_for_status()
        return response.json()
    except Exception as e:
        logger.warning("Error fetching Open Interest for %s: %s", symbol, e)
        return []
```

### 6.1.5 `evaluate_squeeze_risk(fng_value, fr, oi_usd) -> dict`
- **Chức năng:** Heuristic cốt lõi tính rủi ro thanh lý phái sinh dựa trên kết hợp đồng thời ba yếu tố: sentiment cực đoan, đòn bẩy cao, và funding lệch lớn.

```python
def evaluate_squeeze_risk(fng_value: int, fr: float, oi_usd: float) -> dict:
    # Ngưỡng kích hoạt rủi ro thanh lý
    fng_extreme_greed = 85
    fng_extreme_fear = 15
    fr_high_threshold = 0.0005    # 0.05%
    fr_low_threshold = -0.0005    # -0.05%
    oi_high_threshold = 5e9       # 5 tỷ USD đòn bẩy tích lũy

    is_greed = fng_value >= fng_extreme_greed
    is_fear = fng_value <= fng_extreme_fear
    is_fr_long_crowded = fr >= fr_high_threshold
    is_fr_short_crowded = fr <= fr_low_threshold
    is_oi_high = oi_usd >= oi_high_threshold

    # Đếm số điều kiện thỏa mãn
    greed_conditions = sum([is_greed, is_fr_long_crowded, is_oi_high])
    fear_conditions = sum([is_fear, is_fr_short_crowded, is_oi_high])

    if greed_conditions == 3:
        return {"squeeze_type": "long_squeeze_risk", "signal_strength": "high"}
    elif fear_conditions == 3:
        return {"squeeze_type": "short_squeeze_risk", "signal_strength": "high"}
    elif greed_conditions == 2:
        return {"squeeze_type": "long_squeeze_risk", "signal_strength": "medium"}
    elif fear_conditions == 2:
        return {"squeeze_type": "short_squeeze_risk", "signal_strength": "medium"}

    return {"squeeze_type": "none", "signal_strength": "none"}
```

## 6.2 Tương tác Agent & Tool (`agents/utils/crypto_indicator_tools.py`)

### 6.2.1 `@tool get_crypto_indicators(symbol: str) -> str`
- **Chức năng:** Wrapper dùng decorator `@tool` của LangChain để biến `get_crypto_native_indicators` thành công cụ Tool Calling cho LLM.

```python
@tool
def get_crypto_indicators(symbol: str) -> str:
    """Retrieve crypto-native sentiment and leverage metrics (FNG, DOM, FR, OI)
    and compute dynamic liquidation squeeze risk indicators.
    """
    return get_crypto_native_indicators(symbol)
```

## 6.3 Lớp quyết định Graph Flow (`graph/conditional_logic.py`)

### 6.3.1 `should_continue_debate(state: AgentState) -> str`
- **Chức năng:** Quyết định dừng sớm cuộc tranh luận Bull/Bear dựa trên độ đồng thuận tự báo cáo hoặc luân phiên lượt nói. Hard cap = `2 * K_max` lượt.

```python
def should_continue_debate(self, state: AgentState) -> str:
    ds = state["investment_debate_state"]
    count = ds["count"]
    hard_cap = 2 * self.adaptive_debate_k_max  # K_max rounds = 2*K_max turns

    # ── Hard cap (luôn luôn được tôn trọng)
    if count >= hard_cap:
        logger.debug("Debate stopped: hard cap reached (count=%d, cap=%d)", count, hard_cap)
        return "Research Manager"

    # ── Kiểm tra đồng thuận (cần ít nhất 1 vòng trao đổi đầy đủ)
    if count >= 2:
        c_bull = ds.get("bull_confidence", 0.5)
        c_bear = ds.get("bear_confidence", 0.5)
        s_k = 1.0 - abs(c_bull - c_bear)
        logger.debug(
            "Debate round count=%d: C_bull=%.2f C_bear=%.2f S_k=%.2f theta=%.2f",
            count, c_bull, c_bear, s_k, self.adaptive_debate_theta,
        )
        if s_k >= self.adaptive_debate_theta:
            logger.debug("Debate stopped: consensus reached (S_k=%.2f >= theta=%.2f)", s_k, self.adaptive_debate_theta)
            return "Research Manager"

    # ── Tiếp tục: luân phiên chuyển đổi quyền nói
    if ds["current_response"].startswith("Bull"):
        return "Bear Researcher"
    return "Bull Researcher"
```

## 6.4 Tác tử tranh luận & phản hồi (`agents/researchers/bull_researcher.py` & `bear_researcher.py`)

### 6.4.1 `_parse_confidence(text: str) -> float`
- **Chức năng:** Trích điểm tự tin từ phản hồi thô của LLM bằng regex; mặc định 0.5 nếu thiếu/sai, giới hạn về [0,1].

```python
def _parse_confidence(text: str) -> float:
    matches = re.findall(r"CONFIDENCE:\s*([0-9]*\.?[0-9]+)", text, re.IGNORECASE)
    if not matches:
        return 0.5
    try:
        value = float(matches[-1])
        return max(0.0, min(1.0, value))  # Giới hạn trong khoảng [0.0, 1.0]
    except ValueError:
        return 0.5
```

## 6.5 Lớp Vector Memory (`agents/utils/vector_memory.py`)

### 6.5.1 `_ngram_embed(text: str, dim: int = 128) -> List[float]`
- **Chức năng:** Sinh vector pseudo-embedding theo tần suất ký tự tri-gram (fallback khi thiếu `sentence-transformers`).

```python
def _ngram_embed(text: str, dim: int = 128) -> List[float]:
    import hashlib
    vec = [0.0] * dim
    text_norm = text.lower()
    for i in range(len(text_norm) - 2):
        tri = text_norm[i : i + 3]
        h = int(hashlib.md5(tri.encode()).hexdigest(), 16) % dim
        vec[h] += 1.0
    norm = sum(v * v for v in vec) ** 0.5 or 1.0
    return [v / norm for v in vec]
```

### 6.5.2 `RegimeAwareVectorMemory.retrieve(...)`
- **Chức năng:** Truy xuất 2 bước — lọc metadata theo pha thị trường rồi xếp hạng tương đồng cosine (over-fetch `k*4` rồi cắt top-k).

```python
def retrieve(
    self,
    *,
    ticker: str,
    regime: str,
    query_text: str,
    top_k: Optional[int] = None,
) -> List[dict]:
    if not self._available or self._collection.count() == 0:
        return []

    k = top_k or self.top_k
    regime_tag = regime if regime in self.REGIME_LABELS else "Sideway"
    query_embedding = self._embed(query_text)

    # ── Bước 1: Lọc pre-filter theo regime (Bull/Bear/Sideway hoặc ANY)
    try:
        results = self._collection.query(
            query_embeddings=[query_embedding],
            n_results=min(k * 4, self._collection.count()),  # over-fetch
            where={"regime": {"$in": [regime_tag, "ANY"]}},
            include=["documents", "metadatas"],
        )
    except Exception as exc:
        logger.warning("VectorMemory: ChromaDB query failed: %s", exc)
        return []

    # ── Bước 2: Trích xuất danh sách đã xếp hạng bởi ChromaDB
    memories = []
    docs = results.get("documents", [[]])[0]
    metas = results.get("metadatas", [[]])[0]

    for doc, meta in zip(docs, metas):
        memories.append({
            "ticker": meta.get("ticker", ""),
            "regime": meta.get("regime", ""),
            "trade_date": meta.get("trade_date", ""),
            "rating": meta.get("rating", ""),
            "raw_return": meta.get("raw_return", 0.0),
            "alpha_return": meta.get("alpha_return", 0.0),
            "reflection": doc,
        })
        if len(memories) >= k:
            break

    return memories
```

## 6.6 Lớp điều phối bộ nhớ (`agents/utils/memory.py`)

### 6.6.1 `TradingMemoryLog.get_past_context(...)`
- **Chức năng:** Lấy ngữ cảnh kinh nghiệm quá khứ — ưu tiên nhánh C2 (Vector Memory ChromaDB), fallback về FIFO gốc khi không khả dụng.

```python
def get_past_context(self, ticker: str, n_same: int = 5, n_cross: int = 3, regime: str = "") -> str:
    # ── Nhánh C2 Vector Memory
    if self._vector_memory is not None and regime and self._vector_memory.available:
        query = f"Trading decision for {ticker} in {regime} regime"
        memories = self._vector_memory.retrieve(
            ticker=ticker,
            regime=regime,
            query_text=query,
        )
        if memories:
            return self._vector_memory.format_for_prompt(memories)

    # ── Nhánh FIFO Fallback gốc
    entries = [e for e in self.load_entries() if not e.get("pending")]
    if not entries:
        return ""

    same, cross = [], []
    for e in reversed(entries):
        if len(same) >= n_same and len(cross) >= n_cross:
            break
        if e["ticker"] == ticker and len(same) < n_same:
            same.append(e)
        elif e["ticker"] != ticker and len(cross) < n_cross:
            cross.append(e)

    if not same and not cross:
        return ""

    parts = []
    if same:
        parts.append(f"Past analyses of {ticker} (most recent first):")
        parts.extend(self._format_full(e) for e in same)
    if cross:
        parts.append("Recent cross-ticker lessons:")
        parts.extend(self._format_reflection_only(e) for e in cross)
    return "\n\n".join(parts)
```

## 6.7 Bản đồ phương thức → trụ cột cải tiến

| Phương thức / file | Trụ cột | Vai trò trong pipeline |
|---|---|---|
| `crypto_indicators.py` (fetch_*, evaluate_squeeze_risk) | D | Lấy FNG/DOM/FR/OI và đánh giá squeeze (PHASE 1, Market Analyst) |
| `get_crypto_indicators` (@tool) | D | Cầu nối Tool Calling cho Market Analyst |
| `should_continue_debate` | D | Dừng sớm tranh luận theo đồng thuận (PHASE 2) |
| `_parse_confidence` | D | Trích điểm CONFIDENCE của Bull/Bear (PHASE 2) |
| `_ngram_embed`, `RegimeAwareVectorMemory.retrieve` | C2 | Truy xuất ký ức theo pha + cosine (PHASE 0) |
| `TradingMemoryLog.get_past_context` | C1 + C2 | Điều phối đọc bộ nhớ (vector hoặc FIFO fallback) (PHASE 0) |
